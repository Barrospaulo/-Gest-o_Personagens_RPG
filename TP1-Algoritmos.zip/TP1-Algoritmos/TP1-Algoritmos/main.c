#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_PERSONAGENS 100
#define NOME_MAX 50

// Estrutura que representa o personagem
typedef struct {
    int id;
    char nome[50];  // Assume que o nome � uma string de at� 50 caracteres
    int nivel;
    char classe;  // 'G' para Guerreiro, 'M' para Mago, 'A' para Arqueiro
    int hp;
    int ouro;
} Personagem;

// Fun��o para adicionar um novo personagem
void adicionarPersonagem(Personagem personagens[], int *quantidade) {
    if (*quantidade >= MAX_PERSONAGENS) {
        printf("Erro: Numero maximo de personagens atingido!\n");
        return;
    }

    Personagem novo;
    
    // Atribuir um ID �nico ao personagem
    novo.id = *quantidade + 1;

    printf("Nome do personagem: ");
    scanf(" %[^\n]%*c", novo.nome);  // L� o nome do personagem, incluindo espa�os

    printf("Nivel do personagem: ");
    scanf("%d", &novo.nivel);        // L� o n�vel do personagem

    printf("Classe do personagem (G - Guerreiro, M - Mago, A - Arqueiro): ");
    scanf(" %c", &novo.classe);       // L� a classe do personagem

    printf("Pontos de vida (HP): ");
    scanf("%d", &novo.hp);            // L� os pontos de vida do personagem

    printf("Quantidade de ouro: ");
    scanf("%d", &novo.ouro);          // L� a quantidade de ouro do personagem

    personagens[*quantidade] = novo;  // Adiciona o personagem ao array
    (*quantidade)++;                  // Incrementa a quantidade de personagens

    printf("Personagem '%s' adicionado com sucesso!\n", novo.nome);
}

// Fun��o para listar todos os personagens
void listarPersonagens(Personagem personagens[], int quantidade) {
    if (quantidade == 0) {
        printf("Nenhum personagem cadastrado!\n");
        return;
    }

    printf("\nLista de Personagens:\n");

    int i;
    for (i = 0; i < quantidade; i++) {
        printf("ID: %d\n", personagens[i].id);
        printf("Nome: %s\n", personagens[i].nome);
        printf("Nivel: %d\n", personagens[i].nivel);
        printf("Classe: %c\n", personagens[i].classe);
        printf("HP: %d\n", personagens[i].hp);
        printf("Ouro: %d\n", personagens[i].ouro);
        printf("-------------\n");
    }
}

// Fun��o para listar personagens de uma classe espec�fica
void listarPorClasse(Personagem personagens[], int quantidade, char classe) {
    int encontrado = 0;

    printf("\nPersonagens da classe '%c':\n", classe);
    int i;
    for (i = 0; i < quantidade; i++) {
        if (personagens[i].classe == classe) {
            printf("ID: %d\n", personagens[i].id);
            printf("Nome: %s\n", personagens[i].nome);
            printf("Nivel: %d\n", personagens[i].nivel);
            printf("Classe: %c\n", personagens[i].classe);  
            printf("HP: %d\n", personagens[i].hp);
            printf("Ouro: %d\n", personagens[i].ouro);
            printf("-------------\n");
            encontrado = 1;
        }
    }
    
    if (!encontrado) {
        printf("Nenhum personagem encontrado para a classe '%c'.\n", classe);
    }
}

// Fun��o para modificar o n�vel e/ou HP de um personagem espec�fico
void modificarPersonagem(Personagem personagens[], int quantidade) {
    int id, novoNivel, novoHp;
    int encontrado = 0;

    printf("Digite o ID do personagem que deseja modificar: ");
    scanf("%d", &id);
    
    int i;
    for (i = 0; i < quantidade; i++) {
        if (personagens[i].id == id) {
            encontrado = 1;

            // Exibe as informa��es do personagem antes da modifica��o
            printf("\nPersonagem encontrado:\n");
            printf("ID: %d\n", personagens[i].id);
            printf("Nome: %s\n", personagens[i].nome);
            printf("Nivel: %d\n", personagens[i].nivel);
            printf("Classe: %c\n", personagens[i].classe);  
            printf("HP: %d\n", personagens[i].hp);
            printf("Ouro: %d\n", personagens[i].ouro);
            printf("-------------\n");

            // Pergunta ao usu�rio se deseja modificar o n�vel e/ou o HP
            printf("Digite o novo nivel (ou -1 para n�o modificar): ");
            scanf("%d", &novoNivel);
            if (novoNivel != -1) {
                personagens[i].nivel = novoNivel;
            }

            printf("Digite o novo HP (ou -1 para nao modificar): ");
            scanf("%d", &novoHp);
            if (novoHp != -1) {
                personagens[i].hp = novoHp;
            }

            // Exibe as informa��es do personagem ap�s a modifica��o
            printf("\nPersonagem atualizado:\n");
            printf("ID: %d\n", personagens[i].id);
            printf("Nome: %s\n", personagens[i].nome);
            printf("Nivel: %d\n", personagens[i].nivel);
            printf("Classe: %c\n", personagens[i].classe);  
            printf("HP: %d\n", personagens[i].hp);
            printf("Ouro: %d\n", personagens[i].ouro);
            printf("-------------\n");

            printf("Personagem '%s' atualizado com sucesso!\n", personagens[i].nome);
            break;
        }
    }
    
    if (!encontrado) {
        printf("Personagem com ID %d nao encontrado.\n", id);
    }
}

// Fun��o para calcular o n�vel m�dio das personagens de uma classe espec�fica 
void calcularNivelMedio(Personagem personagens[], int quantidade, char classe) {
    int somaNivel = 0;
    int contador = 0;

    // Percorre todos os personagens da lista
    int i;
    for (i = 0; i < quantidade; i++) {
        if (personagens[i].classe == classe) {
            somaNivel += personagens[i].nivel;
            contador++;

            // Exibe as informa��es do personagem da classe selecionada
            printf("\nInforma��es do personagem da classe '%c':\n", classe);
            printf("ID: %d\n", personagens[i].id);
            printf("Nome: %s\n", personagens[i].nome);
            printf("Nivel: %d\n", personagens[i].nivel);
            printf("HP: %d\n", personagens[i].hp);
            printf("Ouro: %d\n", personagens[i].ouro);
            printf("-------------\n");
        }
    }

    if (contador > 0) {
        // Calcula e exibe a m�dia de n�vel das personagens da classe selecionada
        printf("\nNivel medio das personagens da classe '%c': %.2f\n", classe, (float)somaNivel / contador);
    } else {
        printf("Nenhum personagem encontrado para a classe '%c'.\n", classe);
    }
}

// Fun��o para calcular a m�dia de ouro de todos os personagens e mostrar todas as informa��es
void calcularMediaOuro(Personagem personagens[], int quantidade) {
    int somaOuro = 0;

    // Percorre todos os personagens e soma o ouro
    int i;
    for (i = 0; i < quantidade; i++) {
        // Exibe todas as informa��es do personagem, incluindo ID, nome e ouro
        printf("\nPersonagem ID: %d\n", personagens[i].id);
        printf("Nome: %s\n", personagens[i].nome);
        printf("Ouro: %d\n", personagens[i].ouro);
        somaOuro += personagens[i].ouro;
    }

    if (quantidade > 0) {
        // Calcula e exibe a m�dia de ouro
        printf("\nM�dia de ouro de todos os personagens: %.2f\n", (float)somaOuro / quantidade);
    } else {
        printf("Nenhum personagem cadastrado para calcular a m�dia de ouro.\n");
    }
}

// Fun��o para apresentar a(s) personagem(ns) com o maior nivel
void personagemComMaiorNivel(Personagem personagens[], int quantidade) {
    if (quantidade == 0) {
        printf("Nenhum personagem cadastrado!\n");
        return;
    }

    int i;
    int maiorNivel = personagens[0].nivel;
    // Encontrar o maior n�vel
    for (i = 1; i < quantidade; i++) {
        if (personagens[i].nivel > maiorNivel) {
            maiorNivel = personagens[i].nivel;
        }
    }

    // Listar todos os personagens com o maior n�vel
    printf("\nPersonagem(ns) com o maior nivel (%d):\n", maiorNivel);
    for (i = 0; i < quantidade; i++) {
        if (personagens[i].nivel == maiorNivel) {
            printf("ID: %d\n", personagens[i].id);
            printf("Nome: %s\n", personagens[i].nome);
            printf("Nivel: %d\n", personagens[i].nivel);
            printf("Classe: %c\n", personagens[i].classe);  
            printf("HP: %d\n", personagens[i].hp);
            printf("Ouro: %d\n", personagens[i].ouro);
            printf("-------------\n");
        }
    }
}

// Fun��o para apresentar a(s) personagem(ns) com n�vel abaixo da m�dia geral
void personagensAbaixoDaMedia(Personagem personagens[], int quantidade) {
    if (quantidade == 0) {
        printf("Nenhum personagem cadastrado!\n");
        return;
    }

    int somaNivel = 0;
    int i;
    
    // Calcular a soma de todos os n�veis
    for (i = 0; i < quantidade; i++) {
        somaNivel += personagens[i].nivel;
    }

    // Calcular a m�dia geral
    float media = (float)somaNivel / quantidade;

    printf("\nPersonagens com nivel abaixo da media geral (%.2f):\n", media);
    
    // Listar todos os personagens com n�vel abaixo da m�dia
    int encontrado = 0;
    for (i = 0; i < quantidade; i++) {
        if (personagens[i].nivel < media) {
            printf("ID: %d\n", personagens[i].id);
            printf("Nome: %s\n", personagens[i].nome);
            printf("Nivel: %d\n", personagens[i].nivel);
            printf("Classe: %c\n", personagens[i].classe);  
            printf("HP: %d\n", personagens[i].hp);
            printf("Ouro: %d\n", personagens[i].ouro);
            printf("-------------\n");
            encontrado = 1;
        }
    }

    if (!encontrado) {
        printf("Nenhum personagem com nivel abaixo da media geral.\n");
    }
}

// Fun��o para calcular a classe com maior n�mero de personagens e o total de ouro
void classeComMaiorNumeroDePersonagens(Personagem personagens[], int quantidade) {
    int contagemClasseG = 0, contagemClasseM = 0, contagemClasseA = 0;
    int ouroClasseG = 0, ouroClasseM = 0, ouroClasseA = 0;
    Personagem personagensClasseG[MAX_PERSONAGENS], personagensClasseM[MAX_PERSONAGENS], personagensClasseA[MAX_PERSONAGENS];
    int indexClasseG = 0, indexClasseM = 0, indexClasseA = 0;

    // Conta a quantidade de personagens por classe e soma o ouro de cada classe
    int i;
    for (i = 0; i < quantidade; i++) {
        if (personagens[i].classe == 'G') {
            contagemClasseG++;
            ouroClasseG += personagens[i].ouro;
            personagensClasseG[indexClasseG++] = personagens[i];  // Armazena o personagem na classe G
        } else if (personagens[i].classe == 'M') {
            contagemClasseM++;
            ouroClasseM += personagens[i].ouro;
            personagensClasseM[indexClasseM++] = personagens[i];  // Armazena o personagem na classe M
        } else if (personagens[i].classe == 'A') {
            contagemClasseA++;
            ouroClasseA += personagens[i].ouro;
            personagensClasseA[indexClasseA++] = personagens[i];  // Armazena o personagem na classe A
        }
    }

    // Determina a classe com o maior n�mero de personagens
    if (contagemClasseG >= contagemClasseM && contagemClasseG >= contagemClasseA) {
        printf("\nClasse com maior numero de personagens: Guerreiro (G)\n");
        printf("Numero de personagens: %d\n", contagemClasseG);
        printf("Total de ouro acumulado: %d\n", ouroClasseG);
        printf("Detalhes dos personagens:\n");
        for (i = 0; i < contagemClasseG; i++) {
            printf("ID: %d\n", personagensClasseG[i].id);
            printf("Nome: %s\n", personagensClasseG[i].nome);
            printf("Nivel: %d\n", personagensClasseG[i].nivel);
            printf("Classe: %c\n", personagensClasseG[i].classe);  
            printf("HP: %d\n", personagensClasseG[i].hp);
            printf("Ouro: %d\n", personagensClasseG[i].ouro);
            printf("-------------\n");
        }
    } else if (contagemClasseM >= contagemClasseG && contagemClasseM >= contagemClasseA) {
        printf("\nClasse com maior numero de personagens: Mago (M)\n");
        printf("Numero de personagens: %d\n", contagemClasseM);
        printf("Total de ouro acumulado: %d\n", ouroClasseM);
        printf("Detalhes dos personagens:\n");
        for (i = 0; i < contagemClasseM; i++) {
            printf("ID: %d\n", personagensClasseM[i].id);
            printf("Nome: %s\n", personagensClasseM[i].nome);
            printf("Nivel: %d\n", personagensClasseM[i].nivel);
            printf("Classe: %c\n", personagensClasseM[i].classe);  
            printf("HP: %d\n", personagensClasseM[i].hp);
            printf("Ouro: %d\n", personagensClasseM[i].ouro);
            printf("-------------\n");
        }
    } else {
        printf("\nClasse com maior numero de personagens: Arqueiro (A)\n");
        printf("Numero de personagens: %d\n", contagemClasseA);
        printf("Total de ouro acumulado: %d\n", ouroClasseA);
        printf("Detalhes dos personagens:\n");
        for (i = 0; i < contagemClasseA; i++) {
            printf("ID: %d\n", personagensClasseA[i].id);
            printf("Nome: %s\n", personagensClasseA[i].nome);
            printf("Nivel: %d\n", personagensClasseA[i].nivel);
            printf("Classe: %c\n", personagensClasseA[i].classe);  
            printf("HP: %d\n", personagensClasseA[i].hp);
            printf("Ouro: %d\n", personagensClasseA[i].ouro);
            printf("-------------\n");
        }
    }
}

// Fun��o para analisar falhas na dungeon e perdas de ouro
void analisarFalhasDungeon(Personagem personagens[], int quantidade) {
    int falhasClasseG = 0, falhasClasseM = 0, falhasClasseA = 0;
    int totalPerderamDinheiro = 0; // Contador de personagens que perderam dinheiro
    int i;
    
    // Percorrer todos os personagens para verificar falhas na dungeon
    for (i = 0; i < quantidade; i++) {
        if (personagens[i].hp < 50) {
            // Se o personagem tem menos de 50 HP, ele falha e perde 25% do seu ouro
            int ouroPerdido = personagens[i].ouro * 0.25;
            personagens[i].ouro -= ouroPerdido;  // Atualiza o ouro do personagem

            // Contabiliza a falha por classe
            if (personagens[i].classe == 'G') {
                falhasClasseG++;
            } else if (personagens[i].classe == 'M') {
                falhasClasseM++;
            } else if (personagens[i].classe == 'A') {
                falhasClasseA++;
            }

            // Conta quantos personagens perderam dinheiro
            totalPerderamDinheiro++;

            // Exibe informa��es do personagem que falhou e o ouro perdido
            printf("\nPersonagem com falha na dungeon:\n");
            printf("ID: %d\n", personagens[i].id);
            printf("Nome: %s\n", personagens[i].nome);
            printf("Nivel: %d\n", personagens[i].nivel);
            printf("Classe: %c\n", personagens[i].classe);
            printf("HP: %d\n", personagens[i].hp);
            printf("Ouro antes da falha: %d\n", personagens[i].ouro + ouroPerdido);  // Exibe o ouro antes da falha
            printf("Ouro perdido: %d\n", ouroPerdido);
            printf("Ouro restante: %d\n", personagens[i].ouro);
            printf("-------------\n");
        }
    }

    // Exibe o total de falhas por classe
    printf("\nTotal de falhas na dungeon e perdas de ouro:\n");
    printf("Guerreiros (G) com falha: %d\n", falhasClasseG);
    printf("Magos (M) com falha: %d\n", falhasClasseM);
    printf("Arqueiros (A) com falha: %d\n", falhasClasseA);

    // Exibe o total de personagens que perderam dinheiro
    printf("\nTotal de personagens que perderam dinheiro: %d\n", totalPerderamDinheiro);
}

// Fun��o para analisar falhas na dungeon e perdas de ouro
void calcularOuroPerdidoDungeon(Personagem personagens[], int quantidade) {
    int falhasClasseG = 0, falhasClasseM = 0, falhasClasseA = 0;
    int totalPerderamDinheiro = 0; // Contador de personagens que perderam dinheiro
    int totalOuroPerdido = 0;  // Vari�vel para somar o total de ouro perdido
    int i;

    // Percorrer todos os personagens para verificar falhas na dungeon
    for (i = 0; i < quantidade; i++) {
        if (personagens[i].hp < 50) {
            // Se o personagem tem menos de 50 HP, ele falha e perde 25% do seu ouro
            float ouroPerdido = personagens[i].ouro * 0.25f;  // Declarando como float para garantir precis�o

            // Garantir que o valor perdido seja inteiro
            int ouroPerdidoInt = (int)ouroPerdido;

            totalOuroPerdido += ouroPerdidoInt;  // Soma o ouro perdido ao total

            // Contabiliza a falha por classe
            if (personagens[i].classe == 'G') {
                falhasClasseG++;
            } else if (personagens[i].classe == 'M') {
                falhasClasseM++;
            } else if (personagens[i].classe == 'A') {
                falhasClasseA++;
            }

            // Conta quantos personagens perderam dinheiro
            totalPerderamDinheiro++;

            // Exibe informa��es do personagem que falhou e o ouro perdido
            printf("\nPersonagem com falha na dungeon:\n");
            printf("ID: %d\n", personagens[i].id);
            printf("Nome: %s\n", personagens[i].nome);
            printf("Nivel: %d\n", personagens[i].nivel);
            printf("Classe: %c\n", personagens[i].classe);
            printf("HP: %d\n", personagens[i].hp);
            printf("Ouro antes da falha: %d\n", personagens[i].ouro);  // Exibe o ouro antes da falha
            printf("Ouro perdido: %d\n", ouroPerdidoInt);  // Exibe o ouro perdido como inteiro
            printf("Ouro restante: %d\n", personagens[i].ouro - ouroPerdidoInt);  // Exibe o ouro restante ap�s falha
            printf("-------------\n");
        }
    }

    // Exibe o total de falhas por classe
    printf("\nTotal de falhas na dungeon e perdas de ouro:\n");
    printf("Guerreiros (G) com falha: %d\n", falhasClasseG);
    printf("Magos (M) com falha: %d\n", falhasClasseM);
    printf("Arqueiros (A) com falha: %d\n", falhasClasseA);

    // Exibe o total de personagens que perderam dinheiro
    printf("\nTotal de personagens que perderam dinheiro: %d\n", totalPerderamDinheiro);

    // Exibe o total de ouro perdido caso todos os personagens com HP abaixo de 50 tentassem completar a dungeon
    printf("\nTotal de ouro perdido caso todas as personagens com HP abaixo de 50 tentassem completar a dungeon: %d\n", totalOuroPerdido);
}


int main() {
    Personagem personagens[MAX_PERSONAGENS];  // Array para armazenar personagens
    int quantidade = 0;                       // N�mero de personagens criados
    int opcao;
    char classe;

    do {
        printf("\nMenu:\n");
        printf("1. Adicionar Personagem\n");
        printf("2. Listar Personagens\n");
        printf("3. Listar Personagens por Classe\n");
        printf("4. Modificar Nivel e/ou HP de Personagem\n");
        printf("5. Calcular Nivel Medio de uma Classe\n");
        printf("6. Calcular Media de Ouro de Todos os Personagens\n");
        printf("7. Personagem(ns) com Maior Nivel\n");
        printf("8. Personagem(ns) com Nivel Abaixo da Media\n");
        printf("9. Determinar Classe com Maior Numero de Personagens e Total de Ouro\n");
        printf("10. Analisar Falhas na Dungeon (Personagens com menos de 50 HP)\n");  
        printf("11. Calcular Ouro Perdido na Dungeon (Caso todos os personagens falhassem)\n");  // Nova op��o
        printf("12. Sair\n");
        printf("Escolha uma opcao: ");
        scanf("%d", &opcao);

        switch(opcao) {
            case 1:
                adicionarPersonagem(personagens, &quantidade);
                break;
            case 2:
                listarPersonagens(personagens, quantidade);
                break;
            case 3:
                printf("Digite a classe desejada (G - Guerreiro, M - Mago, A - Arqueiro): ");
                scanf(" %c", &classe);
                listarPorClasse(personagens, quantidade, classe);
                break;
            case 4:
                modificarPersonagem(personagens, quantidade);
                break;
            case 5:
                printf("Digite a classe desejada (G - Guerreiro, M - Mago, A - Arqueiro): ");
                scanf(" %c", &classe);
                calcularNivelMedio(personagens, quantidade, classe);
                break;
            case 6:
                calcularMediaOuro(personagens, quantidade);
                break;
            case 7:
                personagemComMaiorNivel(personagens, quantidade);
                break;
            case 8:
                personagensAbaixoDaMedia(personagens, quantidade);
                break;
            case 9:
                classeComMaiorNumeroDePersonagens(personagens, quantidade);
                break;
            case 10:  // Analisar falhas na dungeon
                analisarFalhasDungeon(personagens, quantidade);
                break;
            case 11:  // Calcular ouro perdido na dungeon caso todos falhassem
                calcularOuroPerdidoDungeon(personagens, quantidade);  // Chama a nova fun��o
                break;
            case 12:
                printf("Saindo...\n");
                break;
            default:
                printf("Opcao invalida!\n");
        }
    } while (opcao != 12);

    return 0;
}
